#pragma once
#include<iostream>
using namespace std;

class HourlyPay
{
private:
	int m_iDay;
	int m_iPay;
	int m_iHour;
	
public:
	void GetNum(int day, int pay = 7500, int hour = 8);
	void ShowResult();
};


#pragma once
#include<iostream>
using namespace std;

class TimesTable
{
private:
	int m_iStart;
	int m_iEnd;

public:
	void GetTT(int start = 2, int end = 9);
	void ShowTT();
	TimesTable();
	~TimesTable();
};


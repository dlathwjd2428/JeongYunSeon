#include "Sum.h"

void Sum::GetFinal(int final)
{
	m_iFinal = final;
}

void Sum::ShowResult()
{
	int sum = 0;
	for (int i = 1; i <= m_iFinal; i++)
	{
		sum += i;
	}
	cout << "1 ~ " << m_iFinal << " �� ��: " << sum << endl;
}
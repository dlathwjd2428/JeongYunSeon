#include "HourlyPay.h"

void HourlyPay::GetNum(int day, int pay, int hour)
{
	m_iDay = day;
	m_iPay = pay;
	m_iHour = hour;
}

void HourlyPay::ShowResult()
{
	cout << "�ñ�: " << m_iPay << endl;
	cout << "�ð�: " << m_iHour << "�ð�\t";
	cout << "�� ��: " << m_iDay << "��" << endl;
	cout << "�޿�: " << m_iPay * m_iHour * m_iDay << endl;
}
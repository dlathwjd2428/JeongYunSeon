#pragma once
#include<iostream>
using namespace std;

class Sum
{
private:
	int m_iFinal;

public:
	void GetFinal(int final = 10);
	void ShowResult();
};


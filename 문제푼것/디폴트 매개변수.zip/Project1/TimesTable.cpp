#include "TimesTable.h"


TimesTable::TimesTable()
{
}

void TimesTable::GetTT(int start, int end)
{
	m_iStart = start;
	m_iEnd = end;
}

void TimesTable::ShowTT()
{
	int i, j;
	for (int i = m_iStart; i <= m_iEnd; i++)
	{
		cout << "====" << i << "��====\t";
	}
	cout << endl;
	for (j = 1; j <= 9; j++)
	{
		for (int i = m_iStart; i <= m_iEnd; i++)
		{
			cout << i << " x " << j << " = " << i * j;
			cout << "\t";
		}
		cout << endl;
	}
}

TimesTable::~TimesTable()
{
}

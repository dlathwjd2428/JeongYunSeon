#include "Character.h"

Character::Character(int x, int y)
{
	m_ix = x;
	m_iy = y;
	m_strSp = "��";
}
void Character::Draw()
{
	m_DrawManger.DrawPoint(m_strSp, m_ix, m_iy);
}
void Character::Move(int x, int y, int Width, int Height)
{
	while (1)
	{
		char key = getch();
		m_DrawManger.ErasePoint(m_ix, m_iy);
		switch (key)
		{
		case KEY_UP:
			if (m_iy - 1 > y)
				m_iy--;
			break;
		case KEY_DOWN:
			if (m_iy + 1 < y + Height - 1)
				m_iy++;
			break;
		case KEY_LEFT:
			if (2 * m_ix - 1 > x + 2)
				m_ix--;
			break;
		case KEY_RIGHT:
			if (2 * m_ix + 1 < x + 2 * (Width - 2))
				m_ix++;
			break;
		}
		Draw();
	}
}

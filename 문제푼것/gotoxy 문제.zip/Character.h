#pragma once
#include"Mecro.h"
#include"MapDraw.h"

enum KEY
{
	KEY_UP = 'w',
	KEY_DOWN = 's',
	KEY_LEFT = 'a',
	KEY_RIGHT = 'd'
};
class Character
{
private:
	int m_ix;
	int m_iy;
	string m_strSp;
	MapDraw m_DrawManger;
public:
	void Draw();
	void Move(int x, int y, int Width, int Height);
	Character(int x, int y);
};


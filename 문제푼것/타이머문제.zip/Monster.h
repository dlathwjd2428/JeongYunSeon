#pragma once
#include"Macro.h"
#include"MapDraw.h"

struct MonInfo
{
	int m_iStamina;
	int m_iPosition;
};

class Monster
{
private:
	int m_iMoveClock;
	MonInfo m_Info;
	MapDraw m_MapDraw;

public:
	Monster();
	void DrawMonster();
	void EraseMonster();
	void MoveMonster();
	void SetMonster(int stamina);
	inline int GetStamina() { return m_Info.m_iStamina; }
	inline int GetPosition() { return m_Info.m_iPosition; }
	inline void GrowStamina() { m_Info.m_iStamina++; }
	inline void DownStamina() { m_Info.m_iStamina--; }
};
#pragma once
#include"Macro.h"
#include"Monster.h"

class MonsterManager
{
private:
	list <Monster> m_MonsterList;
	Monster m_Monster;
	int m_iBirthClock;

public:
	MonsterManager();
	void BirthMonster(int stamina);
	void MoveAllMonster();
	bool LoseCheck();
	void EraseMonster();
	void AttackedMosnter();
	inline void SetMonsters(int stamina)
	{
		m_Monster.SetMonster(stamina);
		m_MonsterList.push_back(m_Monster);
	}
	inline int GetMonPos()
	{ 
		if (m_MonsterList.size() > 0)
			return m_MonsterList.front().GetPosition();
		else
			return -1;
	}
	inline int GetMonStamina()
	{
		return m_MonsterList.front().GetStamina();
	}
	inline void DownMonStamina()
	{
		m_MonsterList.front().DownStamina();
	}
	inline bool EmptyMonster()
	{
		return m_MonsterList.empty();
	}
};

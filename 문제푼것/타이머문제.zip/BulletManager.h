#pragma once
#include"Macro.h"
#include"Bullet.h"

#define BULLETMAX 5

class BulletManager
{
private:
	list<Bullet> m_BulletList;
	int m_iLoadClock;
	int m_iBulletNum;

public:
	BulletManager();
	void MakeBullet();
	void StartBullet();
	void MoveAllBullet();
	void EraseBullet();
	void ErasefrontBullet();
	inline int GetBulletNum() { return m_iBulletNum; }
	inline int DownBullet() { return m_iBulletNum--; }
	inline int GetBulletPos()
	{
		if (m_BulletList.size() > 0)
			return m_BulletList.front().GetBulletPos();
		else
			return -1;
	}
};
#include "BulletManager.h"

BulletManager::BulletManager()
{
	m_iBulletNum = 0;
	m_iLoadClock = clock();
}
void BulletManager::MakeBullet()
{
	int CurClock = clock();
	if (m_iBulletNum < BULLETMAX)
	{
		if (CurClock - m_iLoadClock > TIME_LOAD)
		{
			m_iBulletNum++;
			m_iLoadClock = CurClock;
		}
	}
}
void BulletManager::StartBullet()
{
	Bullet bullet;
	m_BulletList.push_back(bullet);
}
void BulletManager::EraseBullet()
{
	if (m_BulletList.empty() == false)
	{
		m_BulletList.front().EraseBullet();
		m_BulletList.pop_front();
	}
}
void BulletManager::MoveAllBullet()
{
	for (auto iter = m_BulletList.begin(); iter != m_BulletList.end(); iter++)
	{
		iter->MoveBullet();
	}
}
void BulletManager::ErasefrontBullet()
{
	if (m_BulletList.empty() == false)
	{
		if (m_BulletList.front().GetBulletPos() == WIDTH)
			EraseBullet();
	}
}
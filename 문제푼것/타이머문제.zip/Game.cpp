#include "Game.h"

Game::Game()
{
	m_iScore = 0;
	m_bPlayState = false;
}
void Game::Start()
{
	char buf[256];
	sprintf(buf, "mode con: lines=%d cols=%d", HEIGHT + 3, 2 * (WIDTH + 1));
	system(buf);
	m_MapDraw.DrawMidText("�����Ϸ��� �ƹ� Ű�� �����ÿ�.", WIDTH, HEIGHT);
	getch();
	m_bPlayState = true;
	Main();
}
void Game::PrintScore()
{
	m_MapDraw.DrawPoint("����: " + to_string(m_iScore), 0, HEIGHT + 1);
}
void Game::PrintBulletNum()
{
	m_MapDraw.DrawMidText("�Ѿ�: " + to_string(m_BulletManager.GetBulletNum()) + "��", WIDTH, HEIGHT + 1);
}
void Game::Main()
{
	system("cls");
	m_MapDraw.Draw();
	PrintScore();
	PrintBulletNum();
	DrawPlayer();
	while (m_bPlayState == true)
	{
		m_MonsterManager.BirthMonster(m_iScore / UPGRADE + 1);
		m_MonsterManager.MoveAllMonster();
		m_BulletManager.MakeBullet();
		m_BulletManager.MoveAllBullet();
		m_BulletManager.ErasefrontBullet();
		PrintBulletNum();
		if (m_BulletManager.GetBulletPos() + 1 == m_MonsterManager.GetMonPos())
		{ //�Ѿ˰� ���Ͱ� ������ ��
			m_BulletManager.EraseBullet();
			m_MonsterManager.AttackedMosnter();
			m_iScore += 10;
			PrintScore();
		}
 		if (m_BulletManager.GetBulletNum() > 0)
			if(kbhit())
				Shooting();
		if (m_MonsterManager.LoseCheck() == true)
		{
			m_bPlayState = false;
			m_MapDraw.DrawMidText("GAME OVER", WIDTH, 1);
			getch();
			return;
		}
	}
}
void Game::Shooting()
{
	char key = getch();
	switch (key)
	{
	case SPACEBAR:
		m_BulletManager.StartBullet();
		m_BulletManager.DownBullet();
		break;
	}
}
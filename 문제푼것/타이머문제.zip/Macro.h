#pragma once
#include<iostream>
#include<time.h>
#include<Windows.h>
#include<conio.h>
#include<list>
#include<vector>
#include<string>
using namespace std;

#define WIDTH 20
#define HEIGHT 2
#define SPACEBAR 32
#define UPGRADE 50

enum TIME
{
	TIME_LOAD = 3000,
	TIME_SHOOT = 500,
	TIME_BIRTHMONSTER = 5000,
	TIME_MOVEMONSTER = 1000
};
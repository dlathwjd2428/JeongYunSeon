#include "Bullet.h"

Bullet::Bullet()
{
	m_iBulletPos = 1;
	m_iShootClock = clock();
}
void Bullet::MoveBullet()
{
	int CurClock = clock();
	if (CurClock - m_iShootClock > TIME_SHOOT)
	{
		EraseBullet();
		m_iBulletPos++;
		DrawBullet();
		m_iShootClock = CurClock;
	}
}
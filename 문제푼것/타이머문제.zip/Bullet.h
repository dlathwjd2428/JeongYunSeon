#pragma once
#include"Macro.h"
#include"MapDraw.h"

class Bullet
{
private:
	int m_iBulletPos;
	int m_iShootClock;
	MapDraw m_MapDraw;

public:
	Bullet();
	void MoveBullet();
	inline void DrawBullet() { m_MapDraw.DrawPoint("��", m_iBulletPos, 0); }
	inline void EraseBullet() { m_MapDraw.ErasePoint(m_iBulletPos, 0); }
	inline int GetBulletPos() { return m_iBulletPos; }
};


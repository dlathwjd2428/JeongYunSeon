#include "MapDraw.h"

void MapDraw::Draw()
{
	for (int y = 0; y < HEIGHT; y++)
	{
		if (y == 0)
		{
			for (int x = 0; x < WIDTH; x++)
				cout << "  ";
			cout << endl;
		}
		else
			for (int x = 0; x < WIDTH; x++)
				cout << "��";
	}
	cout << endl;
	cout << "�� ���: Spacebar" << endl;
}

void MapDraw::DrawPoint(string str, int x, int y)
{
	gotoxy(2 * x, y);
	cout << str;
	gotoxy(-1, -1);
	return;
}
void MapDraw::ErasePoint(int x, int y)
{
	gotoxy(2 * x, y);
	cout << "  ";
	gotoxy(-1, -1);
	return;
}
void MapDraw::DrawMidText(string str, int x, int y)
{
	if (x > str.size() / 2)
		x -= str.size() / 2;
	gotoxy(x, y);
	cout << str;
	return;
}
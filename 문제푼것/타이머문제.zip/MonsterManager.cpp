#include "MonsterManager.h"

MonsterManager::MonsterManager()
{
	m_iBirthClock = clock();
	Monster monster;
	m_MonsterList.push_back(monster);
}
void MonsterManager::BirthMonster(int stamina)
{
	int CurClock = clock();
	if (CurClock - m_iBirthClock > TIME_BIRTHMONSTER)
	{
		SetMonsters(stamina);
		m_iBirthClock = CurClock;
	}
}
void MonsterManager::MoveAllMonster()
{
	for (auto iter = m_MonsterList.begin(); iter != m_MonsterList.end(); iter++)
	{
		iter->MoveMonster();
	}
}
void MonsterManager::EraseMonster()
{
	m_MonsterList.front().EraseMonster();
	m_MonsterList.pop_front();
}
bool MonsterManager::LoseCheck()
{
	if(m_MonsterList.empty() == false)
		if (m_MonsterList.front().GetPosition() == 1)
			return true;
	return false;
}
void MonsterManager::AttackedMosnter()
{
	DownMonStamina();
	if (GetMonStamina() == 0)
		EraseMonster();
}
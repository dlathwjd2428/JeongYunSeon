#pragma once
#include"MapDraw.h"
#include"Macro.h"
#include"MonsterManager.h"
#include"BulletManager.h"

class Game
{
private:
	MapDraw m_MapDraw;
	MonsterManager m_MonsterManager;
	BulletManager m_BulletManager;
	bool m_bPlayState;
	int m_iScore;
public:
	Game();
	void Start();
	void Main();
	void PrintScore();
	void PrintBulletNum();
	void Shooting();
	inline void DrawPlayer() { m_MapDraw.DrawPoint("��", 0, 0); }
	inline int GetScore() { return m_iScore; }
	inline void UpScore() { m_iScore += 10; }
};
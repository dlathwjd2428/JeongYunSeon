#include "Monster.h"

Monster::Monster()
{
	m_iMoveClock = clock();
	m_Info.m_iStamina = 1;
	m_Info.m_iPosition = WIDTH;
}
void Monster::DrawMonster()
{
	m_MapDraw.DrawPoint("��", m_Info.m_iPosition, 0);
}
void Monster::EraseMonster()
{
	m_MapDraw.ErasePoint(m_Info.m_iPosition, 0);
}
void Monster::MoveMonster()
{
	int CurClock = clock();
	if (CurClock - m_iMoveClock > TIME_MOVEMONSTER)
	{
		EraseMonster();
		m_Info.m_iPosition--;
		DrawMonster();
		m_iMoveClock = CurClock;
	}
}
void Monster::SetMonster(int stamina)
{
	m_Info.m_iStamina = stamina;
	m_Info.m_iPosition = WIDTH;
}
#include"Game.h"

void main()
{
	Game GamePlay;
	GamePlay.Start();
}
#pragma once
#include"Macro.h"
#include"MapDraw.h"

#define INITIAL_UNDO 5

struct Location
{
	int m_ix;
	int m_iy;
};

class Player
{
private:
	MapDraw m_MapDraw;
	string m_strName;
	Location m_Cursor;
	vector <Location> m_vStoneList;
	string m_strCursorIcon;
	string m_strStoneIcon;
	int m_iUndo;
public:
	Player();
	void SetPlayer(int Width, int Height);
	void DeleteStone();
	bool CompareStone(int x, int y);
	void DrawStone(int x, int y);
	void SaveStone(int x, int y);
	void DrawAllStone();
	void CreateStone();
	void DrawCursor();
	void EraseCursor(int Width, int Height);
	void MoveCursor(char key, int Width, int Height);
	void Undo(int Width, int Height);
	bool WinCheck(int Width, int Height);
	int StoneCheck(int x, int y, int addx, int addy, int Width, int Height);
	inline void InputName() { cin >> m_strName; }
	inline string GetName() { return m_strName; }
	inline void WriteName(string name) { m_strName = name; }
	inline int GetUndo() { return m_iUndo; }
	inline void SetUndo(int undo) { m_iUndo = undo; }
	inline void DownUndo() { m_iUndo--; }
	inline Location GetCursor() { return m_Cursor; }
	inline void SetCursorIcon(string icon) { m_strCursorIcon = icon; }
	inline void SetStoneIcon(string icon) { m_strStoneIcon = icon; }
	inline Location GetStoneLocation(int num) { return m_vStoneList.at(num); }
	inline string GetStoneIcon() { return m_strStoneIcon; }
	inline int GetStonenum() { return m_vStoneList.size(); }
	~Player();
};
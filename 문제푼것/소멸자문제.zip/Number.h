#pragma once
#include<iostream>
#include<Windows.h>
#include<string>
using namespace std;

class Number
{
private:
	char* m_chNum;
public:
	Number();
	void SetNum(int bar1, int bar2, string str);
	void ShowNum();
	~Number();
};


#include "Number.h"

Number::Number()
{
	string str;
	m_chNum = NULL;
	while (1)
	{
		cout << "��ȭ��ȣ �Է�: ";
		cin >> str;
		if(str[0] == '0')
		{
			if (str[1] == '1' && str.length() == 11)
			{
				SetNum(3, 8, str);
					break;
			}
			else if (str[1] == '2' && str.length() == 9)
			{
				SetNum(2, 6, str);
					break;
			}
			else if (str[1] >= '3' && str[1] <= '6' && str.length() == 10)
			{
				SetNum(3, 7, str);
				break;
			}
			else
			{
				cout << "��ȣ�� �߸� �Է��ϼ̽��ϴ�." << endl;
				system("pause");
			}
		}
		else
		{
			cout << "��ȣ�� �߸� �Է��ϼ̽��ϴ�." << endl;
			system("pause");
		}
	}
}
void Number::SetNum(int bar1, int bar2, string str)
{
	int i, j;
	m_chNum = new char[str.length() + 3];
	for (i = 0, j = 0; j < str.length(); i++)
	{
		if (i == bar1 || i == bar2)
			m_chNum[i] = '-';
		else
		{
			m_chNum[i] = str[j];
		}
		j++;
	}
	m_chNum[i] = NULL;
}
void Number::ShowNum()
{
	cout << "�ϼ��� ��ȣ: " << m_chNum << endl;
}
Number::~Number()
{
	delete[] m_chNum;
}

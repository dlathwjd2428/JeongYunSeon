#include"Number.h"

void main()
{
	Number Num;
	Num.ShowNum();
}
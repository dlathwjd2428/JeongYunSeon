#include"Game.h"

void main()
{
	srand(time(NULL));
	Game game;
	game.Start();
}
#include "Game.h"

Game::Game()
{
	m_iWidth = WIDTH;
	m_iHeight = HEIGHT;
	m_bPlayState = false;
	m_iTurn = 1;
	m_Player[PTYPE_BLACK].SetCursorIcon(BLACKSTONE);
	m_Player[PTYPE_BLACK].SetStoneIcon(BLACKSTONE);
	m_Player[PTYPE_WHITE].SetCursorIcon(WHITESTONE);
	m_Player[PTYPE_WHITE].SetStoneIcon(WHITESTONE);
}

void Game::StartMenu()
{
	m_MapDraw.DrawMidText("�� �� �� ��", m_iWidth, m_iHeight * 0.1f);
	m_MapDraw.DrawMidText("1. ���� ����", m_iWidth, m_iHeight * 0.2f);
	m_MapDraw.DrawMidText("2. �̾ �ϱ�", m_iWidth, m_iHeight * 0.3f);
	m_MapDraw.DrawMidText("3. ���÷���", m_iWidth, m_iHeight * 0.4f);
	m_MapDraw.DrawMidText("4. �ɼ� ����", m_iWidth, m_iHeight * 0.5f);
	m_MapDraw.DrawMidText("5. ���� ����", m_iWidth, m_iHeight * 0.6f);
	m_MapDraw.BoxDraw(m_iWidth, m_iHeight * 0.7f, m_iWidth / 2, 3);
	m_MapDraw.gotoxy(m_iWidth, m_iHeight * 0.7f + 1);
}
void Game::Main()
{
	char buf[256];
	sprintf(buf, "mode con: lines=%d cols=%d", m_iHeight + 5, (2 * m_iWidth) + 1);
	system(buf);
	while (1)
	{
		system("cls");
		m_MapDraw.BoardDraw(m_iWidth, m_iHeight); //������ ũ�⸸ŭ �������� �׸�
		StartMenu(); //�޴��� �ҷ���
		int select;
		cin >> select;
		switch (select)
		{
		case GAME_START:
			m_bPlayState = true; //���� �÷��� ����: false -> true
			m_iTurn = 1;
			GameStart();
			break;
		case GAME_CONTINUE:
			m_bPlayState = true;
			Continue();
			break;
		case GAME_REPLAY:
			Replay();
			break;
		case GAME_OPTION:
			OptionMenu();
			break;
		case GAME_EXIT:
			return;
		}
	}
}
void Game::GameStart()
{
	system("cls");
	m_MapDraw.BoxDraw(0, 0, m_iWidth, m_iHeight); //0, 0���� ������ ũ�⸸ŭ �簢�� �׸�
	InputName("P1 �̸�", PTYPE_BLACK, m_iWidth, m_iHeight * 0.3f);
	InputName("P2 �̸�", PTYPE_WHITE, m_iWidth, m_iHeight * 0.5f);
	system("cls");
	m_MapDraw.BoardDraw(m_iWidth, m_iHeight); //������ ����
	KeyInfo();
	PlayerInfo();
	//����Ű �� �÷��̾� ����
	while (m_bPlayState == true)
	{
		m_Player[m_iTurn % 2].DrawCursor(); //�� �÷��̾��� Ŀ���� �׸�
		Omok(); //������ �۵���Ű�� �Լ�
	}
}
void Game::Omok()
{
	char key = getch();
	Location Cursor;
	switch(key)
	{
		case KEY_UP:
		case KEY_DOWN:
		case KEY_LEFT:
		case KEY_RIGHT:
			DrawPoint(); //�����ǿ� ���� ���� �׷��ִ� �Լ�
			m_Player[m_iTurn % 2].MoveCursor(key, m_iWidth, m_iHeight);
			break;
		case KEY_ENTER:
			Cursor = m_Player[m_iTurn % 2].GetCursor();
			if (m_Player[PTYPE_BLACK].CompareStone(Cursor.m_ix, Cursor.m_iy) || m_Player[PTYPE_WHITE].CompareStone(Cursor.m_ix, Cursor.m_iy))
				//Ŀ���� ��ġ�� ���� �̹� �����Ѵٸ� ����Ű�� �۵����� ����
				break;
			m_Player[m_iTurn % 2].CreateStone();
			if (m_Player[m_iTurn % 2].WinCheck(m_iWidth, m_iHeight) == true) //�¸� ��
			{
				m_bPlayState = false;
				m_MapDraw.DrawMidText(m_Player[m_iTurn % 2].GetName() + "�� �¸�!!", m_iWidth, m_iHeight * 0.5f);
				SaveReplay();
				DeleteContinue();
				m_Player[PTYPE_BLACK].DeleteStone();
				m_Player[PTYPE_WHITE].DeleteStone();
				m_iTurn = 1;
				getch();
				return;
			}
			m_iTurn++;
			PlayerInfo();
			SaveContinue();
			break;
		case KEY_ESC:
			m_bPlayState = false;
			break;
		case KEY_UNDO:
			if (m_Player[m_iTurn % 2].GetUndo() > 0 && m_iTurn > 1)
			{
				m_Player[m_iTurn % 2].EraseCursor(m_iWidth, m_iHeight);
				m_Player[m_iTurn % 2].DownUndo();
				m_iTurn--;
				m_Player[m_iTurn % 2].Undo(m_iWidth, m_iHeight);
				PlayerInfo();
				SaveContinue();
			}
			break;
		case KEY_OPTION:
			OptionMenu();
			system("cls");
			m_MapDraw.BoardDraw(m_iWidth, m_iHeight);
			m_Player[PTYPE_BLACK].DrawAllStone();
			m_Player[PTYPE_WHITE].DrawAllStone();
			KeyInfo();
			PlayerInfo();
			break;
	}
}
void Game::InputName(string str, PTYPE type, int x, int y)
{
	m_MapDraw.DrawMidText(str, x, y);
	m_MapDraw.DrawMidText("�Է�: ", x, y + 1);
	m_Player[type].InputName();
	m_Player[type].SetPlayer(m_iWidth, m_iHeight);
}
void Game::KeyInfo()
{
	m_MapDraw.DrawMidText("====����Ű====", m_iWidth, m_iHeight);
	m_MapDraw.DrawMidText("�̵�: A, S, W, D   ������: ENTER", m_iWidth, m_iHeight + 1);
	m_MapDraw.DrawMidText("������: N  �ɼ�: P  ����: ESC", m_iWidth, m_iHeight + 2);
}
void Game::PlayerInfo()
{
	string Name = m_Player[m_iTurn % 2].GetName();
	int UndoNum = m_Player[m_iTurn % 2].GetUndo();
	m_MapDraw.DrawMidText("Player Name: " + Name + "    ������: " + to_string(UndoNum), m_iWidth, m_iHeight + 3);
	m_MapDraw.DrawMidText("Turn: " + to_string(m_iTurn), m_iWidth, m_iHeight + 4);
}
void Game::DrawPoint()
{
	m_MapDraw.Erase(m_Player[m_iTurn % 2].GetCursor().m_ix, m_Player[m_iTurn % 2].GetCursor().m_iy, m_iWidth, m_iHeight);
	//Ŀ���� ������ ������ �����
	m_Player[PTYPE_BLACK].DrawStone(m_Player[m_iTurn % 2].GetCursor().m_ix, m_Player[m_iTurn % 2].GetCursor().m_iy);
	m_Player[PTYPE_WHITE].DrawStone(m_Player[m_iTurn % 2].GetCursor().m_ix, m_Player[m_iTurn % 2].GetCursor().m_iy);
	//���²� ���� ���� �׷��ش�
}
void Game::OptionMenu()
{
	int select;
	while (1)
	{
		system("cls");
		m_MapDraw.BoxDraw(0, 0, m_iWidth, m_iHeight);
		m_MapDraw.DrawMidText("= Option =", m_iWidth, m_iHeight * 0.2f);
		m_MapDraw.DrawMidText("1. Map Size Set", m_iWidth, m_iHeight * 0.3f);
		m_MapDraw.DrawMidText("2. Cursor Custom", m_iWidth, m_iHeight * 0.4f);
		m_MapDraw.DrawMidText("3. Stone Custom", m_iWidth, m_iHeight * 0.5f);
		m_MapDraw.DrawMidText("4. Undo Count Set", m_iWidth, m_iHeight * 0.6f);
		m_MapDraw.DrawMidText("5. Return", m_iWidth, m_iHeight * 0.7f);
		m_MapDraw.DrawMidText("�Է�: ", m_iWidth, m_iHeight * 0.8f);
		cin >> select;
		switch (select)
		{
		case OPTION_MAPSIZE:
			SetMapSize();
			break;
		case OPTION_CURSOR:
			SetCursor();
			break;
		case OPTION_STONE:
			SetStone();
			break;
		case OPTION_UNDO:
			SetUndoNum();
			break;
		case OPTION_RETURN:
			return;
		}
	}
}
void Game::SetMapSize()
{
	int width, height;
	char buf[256];
	system("cls");
	while (1)
	{
		if (m_bPlayState == false)
		{
			m_MapDraw.BoxDraw(0, 0, m_iWidth, m_iHeight);
			m_MapDraw.DrawMidText("Width: ", m_iWidth, m_iHeight * 0.3f);
			cin >> width;
			m_MapDraw.DrawMidText("Height: ", m_iWidth, m_iHeight * 0.4f);
			cin >> height;
			if (width > 90 || width < 20 || height < 20 || height > 45)
			{
				m_MapDraw.DrawMidText("���� �Ұ���", m_iWidth, m_iHeight * 0.3f);
				m_MapDraw.DrawMidText("(����: 20~90, ����: 20~45)", m_iWidth, m_iHeight * 0.4f);
				getch();
				continue;
			}
			SetSize(width, height);
			sprintf(buf, "mode con: lines=%d cols=%d", m_iHeight + 5, (2 * m_iWidth) + 1);
			system(buf);
			break;
		}
		else
		{
			system("cls");
			m_MapDraw.DrawMidText("���� �Ұ���", m_iWidth, m_iHeight * 0.4f);
			m_MapDraw.DrawMidText("(Game Play ��)", m_iWidth, m_iHeight * 0.5f);
			getch();
			break;
		}
	}
}
void Game::SetCursor()
{
	int select;
	system("cls");
	m_MapDraw.BoxDraw(0, 0, m_iWidth, m_iHeight);
	m_MapDraw.DrawMidText("= Set Cursor =", m_iWidth, m_iHeight * 0.2f);
	m_MapDraw.DrawMidText("1. ��, ��", m_iWidth, m_iHeight * 0.3f);
	m_MapDraw.DrawMidText("2. ��, ��", m_iWidth, m_iHeight * 0.4f);
	m_MapDraw.DrawMidText("3. ��, ��", m_iWidth, m_iHeight * 0.5f);
	m_MapDraw.DrawMidText("4. ��, ��", m_iWidth, m_iHeight * 0.6f);
	m_MapDraw.DrawMidText("5. Return", m_iWidth, m_iHeight * 0.7f);
	m_MapDraw.DrawMidText("�Է�: ", m_iWidth, m_iHeight * 0.8f);
	cin >> select;
	switch (select)
	{
	case 1:
		m_Player[PTYPE_BLACK].SetCursorIcon("��");
		m_Player[PTYPE_WHITE].SetCursorIcon("��");
		break;
	case 2:
		m_Player[PTYPE_BLACK].SetCursorIcon("��");
		m_Player[PTYPE_WHITE].SetCursorIcon("��");
		break;
	case 3:
		m_Player[PTYPE_BLACK].SetCursorIcon("��");
		m_Player[PTYPE_WHITE].SetCursorIcon("��");
		break;
	case 4:
		m_Player[PTYPE_BLACK].SetCursorIcon("��");
		m_Player[PTYPE_WHITE].SetCursorIcon("��");
		break;
	case 5:
		return;
	}
}
void Game::SetStone()
{
	int select;
	system("cls");
	m_MapDraw.BoxDraw(0, 0, m_iWidth, m_iHeight);
	m_MapDraw.DrawMidText("= Set Stone =", m_iWidth, m_iHeight * 0.2f);
	m_MapDraw.DrawMidText("1. ��, ��", m_iWidth, m_iHeight * 0.3f);
	m_MapDraw.DrawMidText("2. ��, ��", m_iWidth, m_iHeight * 0.4f);
	m_MapDraw.DrawMidText("3. ��, ��", m_iWidth, m_iHeight * 0.5f);
	m_MapDraw.DrawMidText("4. ��, ��", m_iWidth, m_iHeight * 0.6f);
	m_MapDraw.DrawMidText("5. Return", m_iWidth, m_iHeight * 0.7f);
	m_MapDraw.DrawMidText("�Է�: ", m_iWidth, m_iHeight * 0.8f);
	cin >> select;
	switch (select)
	{
	case 1:
		m_Player[PTYPE_BLACK].SetStoneIcon("��");
		m_Player[PTYPE_WHITE].SetStoneIcon("��");
		break;
	case 2:
		m_Player[PTYPE_BLACK].SetStoneIcon("��");
		m_Player[PTYPE_WHITE].SetStoneIcon("��");
		break;
	case 3:
		m_Player[PTYPE_BLACK].SetStoneIcon("��");
		m_Player[PTYPE_WHITE].SetStoneIcon("��");
		break;
	case 4:
		m_Player[PTYPE_BLACK].SetStoneIcon("��");
		m_Player[PTYPE_WHITE].SetStoneIcon("��");
		break;
	case 5:
		return;
	}
}
void Game::SetUndoNum()
{
	while (1)
	{
		if (m_bPlayState == false)
		{
			int select;
			system("cls");
			m_MapDraw.BoxDraw(0, 0, m_iWidth, m_iHeight);
			m_MapDraw.DrawMidText("= Set Undo =", m_iWidth, m_iHeight * 0.2f);
			m_MapDraw.DrawMidText("1. Set Undo Count", m_iWidth, m_iHeight * 0.3f);
			m_MapDraw.DrawMidText("2. Undo Off", m_iWidth, m_iHeight * 0.4f);
			m_MapDraw.DrawMidText("3. Return", m_iWidth, m_iHeight * 0.5f);
			m_MapDraw.DrawMidText("�Է�: ", m_iWidth, m_iHeight * 0.6f);
			cin >> select;
			switch (select)
			{
			case 1:
				int undonum;
				while (1)
				{
					system("cls");
					m_MapDraw.BoxDraw(0, 0, m_iWidth, m_iHeight);
					m_MapDraw.DrawMidText("������ Ƚ�� �Է�(�ִ� 10ȸ): ", m_iWidth, m_iHeight * 0.5f);
					cin >> undonum;
					if (undonum <= 10 && undonum >= 0)
					{
						m_Player[PTYPE_BLACK].SetUndo(undonum);
						m_Player[PTYPE_WHITE].SetUndo(undonum);
						break;
					}
					m_MapDraw.DrawMidText("������ ���� �ʽ��ϴ�(0~10)", m_iWidth, m_iHeight * 0.6f);
					getch();
				}
				break;
			case 2:
				system("cls");
				m_MapDraw.BoxDraw(0, 0, m_iWidth, m_iHeight);
				m_MapDraw.DrawMidText("������ Off", m_iWidth, m_iHeight * 0.5f);
				m_Player[PTYPE_BLACK].SetUndo(0);
				m_Player[PTYPE_WHITE].SetUndo(0);
				getch();
				break;
			case 3:
				return;
			}
		}
		else
		{
			system("cls");
			m_MapDraw.DrawMidText("���� �Ұ���", m_iWidth, m_iHeight * 0.4f);
			m_MapDraw.DrawMidText("(Game Play ��)", m_iWidth, m_iHeight * 0.5f);
			getch();
			break;
		}
	}
}
void Game::Replay()
{
	ifstream load;
	int x, y;
	int turn;
	string p1, p2;
	system("cls");
	load.open("replay.txt");
	load >> turn >> p1 >> p2;
	if (load.is_open())
	{
		m_MapDraw.BoardDraw(m_iWidth, m_iHeight);
		for (int i = 1; i <= turn; i++)
		{
			Sleep(500);
			if (i % 2 == PTYPE_BLACK)
				m_MapDraw.DrawMidText(p1 + "��", m_iWidth, m_iHeight + 1);
			else
				m_MapDraw.DrawMidText(p2 + "��", m_iWidth, m_iHeight + 1);
			load >> x >> y;
			m_MapDraw.DrawPoint(m_Player[i % 2].GetStoneIcon(), x, y);
			if (i == turn)
			{
				if (i % 2 == PTYPE_BLACK)
					m_MapDraw.DrawMidText(p1 + "�� �¸�!!", m_iWidth, m_iHeight + 1);
				else
					m_MapDraw.DrawMidText(p2 + "�� �¸�!!", m_iWidth, m_iHeight + 1);
			}
		}
		load.close();
		getch();
	}
	else
	{
		m_MapDraw.DrawMidText("�����Ͱ� �������� �ʽ��ϴ�.", m_iWidth, m_iHeight * 0.5);
		getch();
	}
}
void Game::SaveContinue()
{
	Location Stone;
	ofstream save;
	int p1_count = 0;
	int p2_count = 0;
	string p1, p2;
	save.open("save.txt");
	if (save.is_open())
	{
		save << m_iTurn << endl;
		save << m_Player[PTYPE_BLACK].GetName() << " " << m_Player[PTYPE_WHITE].GetName() << endl;
		save << m_Player[PTYPE_BLACK].GetUndo() << " " << m_Player[PTYPE_WHITE].GetUndo() << endl;
		for (int i = 1; i < m_iTurn; i++)
		{
			if (i % 2 == PTYPE_BLACK)
				Stone = m_Player[PTYPE_BLACK].GetStoneLocation(p1_count++);
			else
				Stone = m_Player[PTYPE_WHITE].GetStoneLocation(p2_count++);
			save << Stone.m_ix << " " << Stone.m_iy << endl;
		}
		save.close();
	}
}
void Game::SaveReplay()
{
	Location Stone;
	ofstream save;
	int p1_count = 0;
	int p2_count = 0;
	save.open("replay.txt");
	if (save.is_open())
	{
		save << m_iTurn << endl;
		save << m_Player[PTYPE_BLACK].GetName() << " " << m_Player[PTYPE_WHITE].GetName() << endl;
		for (int i = 1; i <= m_iTurn; i++)
		{
			if (i % 2 == PTYPE_BLACK)
				Stone = m_Player[PTYPE_BLACK].GetStoneLocation(p1_count++);
			else
				Stone = m_Player[PTYPE_WHITE].GetStoneLocation(p2_count++);
			save << Stone.m_ix << " " << Stone.m_iy << endl;
		}
		save.close();
	}
	
}
void Game::Continue()
{
	ifstream load;
	int x, y;
	string p1, p2;
	int undo1, undo2;
	system("cls");
	load.open("save.txt");
	if (CheckContinue() == false)
	{
		m_MapDraw.DrawMidText("�����Ͱ� �������� �ʽ��ϴ�.", m_iWidth, m_iHeight * 0.5);
		getch();
	}
	else
	{
		if (load.is_open())
		{
			load >> m_iTurn;
			load >> p1 >> p2;
			m_Player[PTYPE_BLACK].WriteName(p1);
			m_Player[PTYPE_WHITE].WriteName(p2);
			load >> undo1 >> undo2;
			m_Player[PTYPE_BLACK].SetUndo(undo1);
			m_Player[PTYPE_BLACK].SetUndo(undo2);
			m_MapDraw.BoardDraw(m_iWidth, m_iHeight);
			KeyInfo();
			PlayerInfo();
			if (m_Player->GetStonenum() == 0)
				for (int i = 1; i < m_iTurn; i++)
				{
					load >> x >> y;
					m_Player[i % 2].SaveStone(x, y);
					m_MapDraw.DrawPoint(m_Player[i % 2].GetStoneIcon(), x, y);
				}
			else
			{
				for (int i = 1; i < m_iTurn; i++)
				{
					load >> x >> y;
					m_MapDraw.DrawPoint(m_Player[i % 2].GetStoneIcon(), x, y);
				}
			}
			load.close();
			while (m_bPlayState == true)
			{
				m_Player[m_iTurn % 2].DrawCursor();
				Omok();
			}
		}
		else
		{
			m_MapDraw.DrawMidText("�����Ͱ� �������� �ʽ��ϴ�.", m_iWidth, m_iHeight * 0.5);
			getch();
		}
	}
}
bool Game::CheckContinue()
{
	ifstream load;
	int tmp;
	load.open("save.txt");
	load >> tmp;
	if (tmp == NULL)
		return false;
	else
		return true;
}
void Game::DeleteContinue()
{
	ofstream save;
	save.open("save.txt");
	if (save.is_open())
	{
		save << NULL;
		save.close();
	}
}
Game::~Game()
{
}

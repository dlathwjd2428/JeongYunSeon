#pragma once
#include"Macro.h"
#include"MapDraw.h"
#include"Player.h"

#define BLACKSTONE "��"
#define WHITESTONE "��"

enum GAME
{
	GAME_START = 1,
	GAME_CONTINUE,
	GAME_REPLAY,
	GAME_OPTION,
	GAME_EXIT
};
enum OPTION
{
	OPTION_MAPSIZE = 1,
	OPTION_CURSOR,
	OPTION_STONE,
	OPTION_UNDO,
	OPTION_RETURN
};
enum PTYPE
{
	PTYPE_WHITE,
	PTYPE_BLACK,
	PTYPE_END
};
class Game
{
private:
	MapDraw m_MapDraw;
	Player m_Player[PTYPE_END];
	int m_iWidth;
	int m_iHeight;
	int m_iTurn;
	bool m_bPlayState;
public:
	Game();
	~Game();
	void Main();
	void StartMenu();
	void GameStart();
	void InputName(string str, PTYPE type, int x, int y);
	void KeyInfo();
	void PlayerInfo();
	void Omok();
	void DrawPoint();
	void OptionMenu();
	void SetMapSize();
	void SetCursor();
	void SetStone();
	void SetUndoNum();
	void Replay();
	void SaveContinue();
	void SaveReplay();
	void Continue();
	bool CheckContinue();
	void DeleteContinue();
	inline void SetSize(int width, int height)
	{
		m_iWidth = width;
		m_iHeight = height;
	}
	inline int GetTurn() { return m_iTurn; }
};


#include"Computer.h"

void main()
{
	Computer Com;
	Com.Menu();
}
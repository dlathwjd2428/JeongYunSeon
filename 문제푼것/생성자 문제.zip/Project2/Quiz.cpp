#include "Quiz.h"

Quiz::Quiz()
{
	m_iSum = 0;
	m_iStart = 1;
	m_iEnd = 10;
	ResultSum();
}
Quiz::Quiz(int num)
{
	m_iSum = 0;
	m_iStart = 1;
	m_iEnd = num;
	ResultSum();
}
Quiz::Quiz(int num1, int num2)
{
	m_iSum = 0;
	if (num1 >= num2)
	{
		m_iStart = num2;
		m_iEnd = num1;
	}
	else
	{
		m_iStart = num1;
		m_iEnd = num2;
	}
	ResultSum();
}
void Quiz::ResultSum()
{
	for (int i = m_iStart; i <= m_iEnd; i++)
		m_iSum += i;
}
#pragma once
#include<iostream>
using namespace std;

class Quiz
{
private:
	int m_iSum, m_iStart, m_iEnd;
public:
	Quiz();
	Quiz(int num);
	Quiz(int num1, int num2);
	void ResultSum();
	inline int GetSum()
	{
		return m_iSum;
	}
};


#pragma once
#include<iostream>
#include<string>
#include<Windows.h>
#include<list>
using namespace std;

struct member
{
	string id;
	string password;
	string nickname;
	int age;
	string phonenum;
	int mileage;
};
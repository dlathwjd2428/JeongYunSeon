#include<iostream>
#include<string>
#include"Login.h"
using namespace std;

void main()
{
	Login l;
	l.LoginMenu();
}
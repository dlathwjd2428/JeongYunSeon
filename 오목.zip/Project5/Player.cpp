#include "Player.h"

Player::Player()
{
	m_iUndo = INITIAL_UNDO;
}
void Player::SetPlayer(int Width, int Height)
{
	DeleteStone();
	m_Cursor.m_ix = Width / 2;
	m_Cursor.m_iy = Height / 2;
}
void Player::DeleteStone()
{
	if (m_vStoneList.empty() == false)
		m_vStoneList.clear();
}
void Player::DrawCursor()
{
	m_MapDraw.DrawPoint(m_strCursorIcon, m_Cursor.m_ix, m_Cursor.m_iy);
}
void Player::EraseCursor(int Width, int Height)
{
	m_MapDraw.Erase(m_Cursor.m_ix, m_Cursor.m_iy, Width, Height);
}
void Player::DrawStone(int x, int y)
{
	if (CompareStone(x, y) == true)
		m_MapDraw.DrawPoint(m_strStoneIcon, x, y);
}
bool Player::CompareStone(int x, int y)
{
	if (m_vStoneList.empty() == false)
	{
		for (auto iter = m_vStoneList.begin(); iter != m_vStoneList.end(); iter++)
			if (iter->m_ix == x && iter->m_iy == y)
				return true;
	}
	return false;
}
void Player::MoveCursor(char key, int Width, int Height)
{
	switch (key)
	{
	case KEY_UP:
		if (m_Cursor.m_iy - 1 >= 0)
			m_Cursor.m_iy--;
		break;
	case KEY_DOWN:
		if (m_Cursor.m_iy + 1 < Height)
			m_Cursor.m_iy++;
		break;
	case KEY_LEFT:
		if (m_Cursor.m_ix - 1 >= 0)
			m_Cursor.m_ix--;
		break;
	case KEY_RIGHT:
		if (m_Cursor.m_ix + 1 < Width)
			m_Cursor.m_ix++;
		break;
	}
}
void Player::CreateStone()
{
	if (CompareStone(m_Cursor.m_ix, m_Cursor.m_iy) == false)
	{
		m_vStoneList.push_back(m_Cursor);
		DrawStone(m_Cursor.m_ix, m_Cursor.m_iy);
	}
}
void Player::DrawAllStone()
{
	for (auto iter = m_vStoneList.begin(); iter != m_vStoneList.end(); iter++)
		m_MapDraw.DrawPoint(m_strStoneIcon, iter->m_ix, iter->m_iy);
}
bool Player::WinCheck(int Width, int Height)
{
	int count = 1; //���� ����
	count += StoneCheck(m_Cursor.m_ix - 1, m_Cursor.m_iy, -1, 0, Width, Height);
	count += StoneCheck(m_Cursor.m_ix + 1, m_Cursor.m_iy, 1, 0, Width, Height);
	if (count == 5)
		return true;
	
	count = 1; //���� ����
	count += StoneCheck(m_Cursor.m_ix, m_Cursor.m_iy - 1, 0, -1, Width, Height);
	count += StoneCheck(m_Cursor.m_ix, m_Cursor.m_iy + 1, 0, 1, Width, Height);
	if (count == 5)
		return true;
	
	count = 1; //�آ� ����
	count += StoneCheck(m_Cursor.m_ix - 1, m_Cursor.m_iy - 1, -1, -1, Width, Height);
	count += StoneCheck(m_Cursor.m_ix + 1, m_Cursor.m_iy + 1, 1, 1, Width, Height);
	if (count == 5)
		return true;

	count = 1;
	count += StoneCheck(m_Cursor.m_ix - 1, m_Cursor.m_iy + 1, -1, 1, Width, Height);
	count += StoneCheck(m_Cursor.m_ix + 1, m_Cursor.m_iy - 1, 1, -1, Width, Height);
	if (count == 5)
		return true;

	return false;
}
int Player::StoneCheck(int x, int y, int addx, int addy, int Width, int Height)
{
	int count = 0;
	for (; (x >= 0 && x < Width) && (y >= 0 && y < Height); x += addx, y += addy)
	{
		if (CompareStone(x, y) == true)
			count++;
		else
			break;
	}
	return count;
}
void Player::Undo(int Width, int Height)
{
	m_MapDraw.Erase(m_vStoneList.back().m_ix, m_vStoneList.back().m_iy, Width, Height);
	m_vStoneList.pop_back();
}
void Player::SaveStone(int x, int y)
{
	m_Cursor.m_ix = x;
	m_Cursor.m_iy = y;
	m_vStoneList.push_back(m_Cursor);
}
Player::~Player()
{
}

#include"Omok.h"

void main()
{
	Omok GamePlay;
	GamePlay.Main();
}
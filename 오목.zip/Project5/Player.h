#pragma once
#include"Macro.h"
#include"MapDraw.h"

#define INITIAL_UNDO 5

struct Position
{
	int m_ix;
	int m_iy;
};
class Player
{
private:
	MapDraw m_MapDraw;
	string m_strName;
	Position m_Cursor;
	vector <Position> m_vStoneList;
	string m_strCursorIcon;
	string m_strStoneIcon;
	int m_iUndo;

public:
	Player();
	void SetPlayer(int Width, int Height);
	void DeleteStone();
	void DrawCursor();
	void EraseCursor(int Width, int Height);
	void DrawStone(int x, int y);
	bool CompareStone(int x, int y);
	void MoveCursor(char key, int Width, int Height);
	void CreateStone();
	void DrawAllStone();
	bool WinCheck(int Width, int Height);
	int StoneCheck(int x, int y, int addx, int addy, int Width, int Height);
	void Undo(int Width, int Height);
	void SaveStone(int x, int y);
	inline void InputName() { cin >> m_strName; }
	inline string GetName() { return m_strName; }
	inline int GetUndo() { return m_iUndo; }
	inline Position GetCursor() { return m_Cursor; }
	inline void SetCursorIcon(string icon) { m_strCursorIcon = icon; }
	inline void SetStoneIcon(string icon) { m_strStoneIcon = icon; }
	inline void SetUndo(int undo) { m_iUndo = undo; }
	inline void DownUndo() { m_iUndo--; }
	inline string GetStoneIcon() { return m_strStoneIcon; }
	inline Position GetStonePos(int num) { return m_vStoneList.at(num); }
	inline void WriteName(string name) { m_strName = name; }
	inline int GetStoneNum() { return m_vStoneList.size(); }
	~Player();
};
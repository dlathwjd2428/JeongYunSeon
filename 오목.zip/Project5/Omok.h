#pragma once
#include"Macro.h"
#include"MapDraw.h"
#include"Player.h"

#define BLACKSTONE "��"
#define WHITESTONE "��"

enum GAME
{
	GAME_START = 1,
	GAME_CONTINUE,
	GAME_REPLAY,
	GAME_OPTION,
	GAME_EXIT
};
enum OPTION
{
	OPTION_MAPSIZE = 1,
	OPTION_CURSOR,
	OPTION_STONE,
	OPTION_UNDO,
	OPTION_RETURN
};
enum PTYPE
{
	PTYPE_WHITE,
	PTYPE_BLACK,
	PTYPE_END
};

class Omok
{
private:
	MapDraw m_MapDraw;
	Player m_Player[PTYPE_END];
	int m_iWidth;
	int m_iHeight;
	int m_iTurn;
	bool m_bPlayState;

public:
	Omok();
	void Main();
	void StartMenu();
	void Start();
	void KeyInfo();
	void PlayerInfo();
	void Game();
	void DrawPoint();
	void OptionMenu();
	void SetMapSize();
	void SetCursor();
	void SetStone();
	void SetUndoNum();
	bool CheckContinue();
	void DeleteContinue();
	void SaveContinue();
	void Continue();
	void SaveReplay();
	void Replay();
	void InputName(string str, PTYPE type, int x, int y);
	inline void SetSize(int width, int height)
	{
		m_iWidth = width;
		m_iHeight = height;
	}
};


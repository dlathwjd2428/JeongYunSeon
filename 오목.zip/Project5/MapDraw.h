#pragma once
#include"Macro.h"

class MapDraw
{
public:
	void BoardDraw(int Width, int Height);
	void BoxDraw(int StartX, int StartY, int Width, int Height);
	void DrawPoint(string str, int x, int y);
	void ErasePoint(int x, int y);
	void DrawMidText(string str, int x, int y);
	void Erase(int x, int y, int Width, int Height);
	inline void gotoxy(int x, int y)
	{
		COORD Pos = { x, y };
		SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), Pos);
	}
};

#pragma once
#include "Login.h"

class Computer : public Login
{
private:
	string m_strName, m_strSt, m_strGp, m_strCpu, m_strMm;
	
public:
	Computer();
	void Menu();
	void Status();
	void Program();
};